import React from 'react';

export default function GeneratedAgentWidget() {
  return (
    <div dangerouslySetInnerHTML={{ __html: "<div class=\"p-4 bg-slate-900/95 text-slate-100 rounded-xl border border-cyan-500/40 shadow-lg font-sans\">\n  <div class=\"flex items-center justify-between border-b border-slate-800 pb-2 mb-3\">\n    <span class=\"text-xs font-bold text-cyan-400\">⚡ DOM RENDERER LIVE SANDBOX</span>\n    <span class=\"text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full\">Hydrated @ 07:23:28</span>\n  </div>\n  <h3 class=\"text-sm font-semibold text-white mb-2\">实时神经元视图 · 置信度 98.6%</h3>\n  <div class=\"grid grid-cols-3 gap-2 text-center\">\n    <div class=\"p-2 rounded bg-slate-800/80 border border-slate-700\">\n      <div class=\"text-[10px] text-slate-400\">突触延迟</div>\n      <div class=\"text-sm font-bold text-emerald-400\">8ms</div>\n    </div>\n    <div class=\"p-2 rounded bg-slate-800/80 border border-slate-700\">\n      <div class=\"text-[10px] text-slate-400\">意图置信度</div>\n      <div class=\"text-sm font-bold text-cyan-400\">99.2%</div>\n    </div>\n    <div class=\"p-2 rounded bg-slate-800/80 border border-slate-700\">\n      <div class=\"text-[10px] text-slate-400\">UI 生成率</div>\n      <div class=\"text-sm font-bold text-purple-400\">98.6%</div>\n    </div>\n  </div>\n</div>" }} />
  );
}
